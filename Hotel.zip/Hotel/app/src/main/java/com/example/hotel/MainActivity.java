package com.example.hotel;

import androidx.appcompat.app.AppCompatActivity;

import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Button;
import android.content.Intent;

public class MainActivity extends AppCompatActivity {
    TextView welt;
    Button rb, tb, loc;
    Intent rp, tp;
    String uri="geo:0,0?q=mumbai";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button rb= (Button) findViewById(R.id.rb);
        rb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(MainActivity.this, Book.class);
                startActivity(myIntent);
            }
        });

        Button tb= (Button) findViewById(R.id.tb);
        tb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(MainActivity.this, Reserve.class);
                startActivity(myIntent);
            }
        });

        loc = (Button) findViewById(R.id.loc);
        loc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Uri u= Uri.parse(uri);
                Intent intent= new Intent(Intent.ACTION_VIEW, u);
                intent.setPackage("com.google.android.apps.maps");
                startActivity(intent);
            }
        });


    }
}